class AuthError(Exception):
    pass